/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--prefix=/opt/php81-build' '--with-fpm-user=www' '--with-fpm-group=www' '--enable-fpm' '--with-mysqli' '--with-pdo-mysql' '--with-zlib' '--enable-mbstring' '--enable-gd' '--with-openssl' '--enable-sockets' '--enable-pcntl' '--with-curl' '--with-iconv' '--enable-fileinfo' '--enable-bcmath' '--enable-exif' '--enable-ftp' '--with-zip' '--enable-intl'"
#define PHP_ODBC_CFLAGS	""
#define PHP_ODBC_LFLAGS		""
#define PHP_ODBC_LIBS		""
#define PHP_ODBC_TYPE		""
#define PHP_OCI8_DIR			""
#define PHP_OCI8_ORACLE_VERSION		""
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/opt/php81-build/lib/php/extensions/no-debug-non-zts-20210902"
#define PHP_PREFIX              "/opt/php81-build"
#define PHP_BINDIR              "/opt/php81-build/bin"
#define PHP_SBINDIR             "/opt/php81-build/sbin"
#define PHP_MANDIR              "/opt/php81-build/php/man"
#define PHP_LIBDIR              "/opt/php81-build/lib/php"
#define PHP_DATADIR             "/opt/php81-build/share/php"
#define PHP_SYSCONFDIR          "/opt/php81-build/etc"
#define PHP_LOCALSTATEDIR       "/opt/php81-build/var"
#define PHP_CONFIG_FILE_PATH    "/opt/php81-build/lib"
#define PHP_CONFIG_FILE_SCAN_DIR    ""
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
